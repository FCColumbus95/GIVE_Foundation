# FC Columbus — combined private club website

## GitHub and Cloudflare package

This is the complete GitHub-ready source package for the FC Columbus website. Keep the GitHub repository private because protected member-library source is included for server-side rendering. See `CLOUDFLARE_DEPLOYMENT.md` for the deployment workflow, required GitHub secrets, Cloudflare Worker settings and DNS connection for `fccolumbus95.com`.

Merged the initial FC Columbus Site (version 5) with the newer Joga Bonito Site (version 1). The newer Site identity and URL are retained. Both original source histories remain available; the earlier Site was not changed.

## Combined experience

- Newer responsive visual design, programme tabs, navigation, FAQs and review-before-send enquiry builder.
- Original unaltered uploaded crest and Joga Bonito × Skills = Fun identity.
- Original owner-supplied present FC Columbus and historical Santos FC photographs, framed without cropping in the rotating home gallery.
- Scholar-athlete mission, Sankofa Way, DOORS, school/family/community network, interactive age finder and player pathway.
- A formal members’ centre and library: 15 protected resources across Curriculum & Manuals (8), Handbooks (2), Club Guides (2), and Articles & Reading Notes (3). Dedicated library catalogue with search, combined collection/audience filters, sorting, reset controls, reading times, descriptions and protected individual readers. The complete six-page FC Columbus curriculum and three clearly attributed excerpts augment the eleven original resources. The Hilliard planner, development cycle and reflection tools remain in the development centre.
- Original protected indoor/outdoor concept viewer plus the newer twin-fieldhouse illustration. Detailed schedules and concept images remain server-side.

## Access

Remain owner-private. Never broaden the Site audience without the owner's approval. The member centre independently verifies dispatch identity against FCC_OWNER_EMAIL and FCC_MEMBER_EMAILS on every request; missing identity or configuration fails closed. Runtime membership configuration is stored in Sites, not source.

The public/client output contains only introductory club content, public club photography, UI code and styling. Protected documents, detailed planning data and illustrations are bundled only on the server. Private responses retain no-store/noindex policies and member watermarks. No export controls are added.

Contact info@fccolumbus95.com. FC Columbus is independent and has no cross-club affiliation content. Enquiries are prepared locally and sent by the visitor from their email app; the Site does not submit or store them.

## Verification

Run the retained membership and route tests with `node --test tests/membership.test.mjs`. Build through the Sites helper, then run `node tests/public-boundary.mjs` to check the client artifact for protected source leakage.

Source provenance remains in private-source/identity-sources.json. The latest indoor concept was added to that record. Display font licensing is in public/assets/FONT-LICENSE.txt.

## Formal library update

The library lives at /members/library, linked prominently from the members’ centre. Its server route applies the same membership policy and private headers as all readers. Attributed excerpts link to their full source within the protected library. Source provenance is stored in private-source/library-sources.json. No original document download links were added.

The updated membership/route suite passed all nine tests, covering the new catalogue and all 15 reading pages. Layout and filter checks used synthetic resources only: desktop, 390px, 320px and 768px responsive layouts fit without horizontal overflow; collections, search, empty states, audience filtering and resets worked. Synthetic QA files were removed before publication.

## Members preview navigation fix

Reproduced a blank Members destination by clicking the home-page Members link within an iframe. The protected response combined X-Frame-Options DENY with CSP frame-ancestors none, so the browser refused to display it. Protected responses now allow only the same Site origin and https://chatgpt.com as frame parents. Member identity and approval checks, no-store headers, noindex, source protection and view-only policies are preserved. The exact embedded navigation path is checked in browser QA and the allowed parent policy is covered in the route test suite.

## Club social links

Instagram, Facebook and X/Twitter links are managed in lib/social-links.ts and displayed in the top bar, club-life section, dedicated social area, contact section, footer and protected member page footer. All open in a new tab with noopener/noreferrer. No private-resource sharing controls, social feeds or trackers are added. The existing club link hub is also linked.

Sources: the existing club website identifies Instagram @fccolumbus95; the NPSL club announcement at https://www.npsl.com/4399/ documents Facebook, Instagram and Twitter @fccolumbus95. Direct social profile retrieval was restricted, so current posting activity was not asserted. Exact official YouTube, TikTok, LinkedIn, Threads and any additional account URLs still need to be supplied or confirmed by the owner. Generic share URLs on the link hub are not treated as club profiles.

## Public opportunities

The owner-requested public Tryouts and Programs entry point is https://fc-columbus-community.santosemails1.chatgpt.site. Main navigation, a homepage feature, footer and tryout FAQ link there. This Site remains owner-private; its protected curriculum, library and programme are unchanged.

## Club presentation refresh

The homepage now uses the formal FC Columbus masthead, shared with public Tryouts and Programs, and revised editorial typography, cards, photo presentation, navigation, forms and spacing. The source crest, all three carousel photos, interactions and protected member routes are preserved. public/masthead.css is shared; public/refinement.css contains homepage-specific refinements. scripts/club-masthead.mjs preserves the header generator.

Responsive QA: desktop plus 390px, 320px and 768px layouts; menu open/close and link navigation; original carousel manual controls. The three dot selectors now have independent non-overlapping tap targets and verified 1→2→3 navigation on 320px.
