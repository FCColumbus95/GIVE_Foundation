import test from 'node:test';
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {existsSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

// Isolate the official dispatch identity adapter in tests. These hooks are never
// imported by the application and do not add a production authentication bypass.
registerHooks({
 resolve(specifier,context,next){
  if(specifier==='cloudflare:workers')return {url:'data:text/javascript,export const env=globalThis.__fccTestEnv',shortCircuit:true};
  if(specifier==='next/headers')return {url:'data:text/javascript,export const headers=async()=>globalThis.__fccTestHeaders',shortCircuit:true};
  if(specifier==='next/navigation')return {url:'data:text/javascript,export const redirect=()=>{throw Error("unexpected redirect")}',shortCircuit:true};
  if(specifier.endsWith('?raw'))return {url:new URL(specifier,context.parentURL).href,shortCircuit:true};
  if(specifier.startsWith('.')&&context.parentURL?.startsWith('file:')){
   const url=new URL(specifier,context.parentURL);
   if(!url.pathname.endsWith('.ts')&&!url.pathname.endsWith('.json')&&existsSync(fileURLToPath(url)+'.ts'))return next(url.href+'.ts',context);
  }
  return next(specifier,context);
 },
 load(url,context,next){
  if(url.endsWith('?raw'))return {format:'module',source:'export default '+JSON.stringify(readFileSync(fileURLToPath(new URL(url.replace(/\?raw$/,''))),'utf8')),shortCircuit:true};
  if(url.endsWith('.json'))return {format:'module',source:'export default '+readFileSync(fileURLToPath(url),'utf8'),shortCircuit:true};
  return next(url,context);
 }
});
globalThis.__fccTestEnv={FCC_OWNER_EMAIL:'owner@example.test',FCC_MEMBER_EMAILS:'member@example.test; SECOND@example.test\nthird@example.test'};
globalThis.__fccTestHeaders=new Headers();
const {memberRole,isMember,PRIVATE_HEADERS}=await import('../lib/member-policy.ts');
const config={ownerEmail:'owner@example.test',memberEmails:globalThis.__fccTestEnv.FCC_MEMBER_EMAILS};
const identity=email=>({userId:'site-user-123',email,displayName:'Test member'});
const setIdentity=email=>{globalThis.__fccTestHeaders=new Headers(email?{'oai-authenticated-user-id':'site-user-123','oai-authenticated-user-email':email}:{});};
const routes=[
 ['/members',await import('../app/members/route.ts'),{}],
 ['/members/library',await import('../app/members/library/route.ts'),{}],
 ['/members/library/doors-handbook',await import('../app/members/library/[slug]/route.ts'),{slug:'doors-handbook'}],
 ['/members/programme',await import('../app/members/programme/route.ts'),{}],
 ['/members/content/programme.js',await import('../app/members/content/[asset]/route.ts'),{asset:'programme.js'}],
 ['/members/content/campus.png',await import('../app/members/content/[asset]/route.ts'),{asset:'campus.png'}],
 ['/members/content/indoor.png',await import('../app/members/content/[asset]/route.ts'),{asset:'indoor.png'}],
 ['/members/content/twin-halls.webp',await import('../app/members/content/[asset]/route.ts'),{asset:'twin-halls.webp'}]
];
test('membership fails closed and normalizes only approved identities',()=>{
 for(const user of [null,{},identity(''),{...identity(config.ownerEmail),userId:''}])assert.equal(isMember(memberRole(user,config)),false);
 assert.equal(memberRole(identity('outsider@example.test'),config),'pending');
 assert.equal(memberRole(identity(' OWNER@example.test '),config),'owner');
 for(const email of ['member@example.test','second@example.test','third@example.test'])assert.equal(memberRole(identity(email),config),'member');
 assert.equal(memberRole(identity('owner@example.test'),{ownerEmail:'',memberEmails:'owner@example.test'}),'unconfigured');
});
test('every protected route rejects anonymous and unapproved accounts without content',async()=>{
 for(const email of [null,'outsider@example.test']){
  setIdentity(email);
  for(const [path,route,params]of routes){
   const response=await route.GET(new Request('https://club.test'+path+'?member=true&email=owner@example.test'),{params:Promise.resolve(params)});
   assert.equal(response.status,email?403:401,path);
   assert.match(response.headers.get('cache-control'),/no-store/);
   assert.equal(response.headers.get('x-robots-tag'),PRIVATE_HEADERS['X-Robots-Tag']);
   const body=await response.text();
   assert.doesNotMatch(body,/manual-paper|data-manual-card|id="pilot-data"|Two learning days|Ball mastery, coordination|base64|data-moment|Bermuda-grass/);
  }
 }
});
test('approved owner and member receive each resource with private response headers',async()=>{
 for(const email of ['owner@example.test','member@example.test']){
  setIdentity(email);
  for(const [path,route,params]of routes){
   const response=await route.GET(new Request('https://club.test'+path),{params:Promise.resolve(params)});
   assert.equal(response.status,200,path);
   for(const[key,value]of Object.entries(PRIVATE_HEADERS))assert.equal(response.headers.get(key),value,path+' '+key);
   if(/\.(png|webp)$/.test(path))assert.equal((await response.arrayBuffer()).byteLength>100000,true);
   else assert.equal((await response.text()).length>500,true);
  }
 }
});
test('missing membership configuration cannot unlock content',async()=>{
 setIdentity('owner@example.test');const before=globalThis.__fccTestEnv.FCC_OWNER_EMAIL;globalThis.__fccTestEnv.FCC_OWNER_EMAIL='';
 const response=await routes[0][1].GET(new Request('https://club.test/members'));
 assert.equal(response.status,503);assert.doesNotMatch(await response.text(),/data-manual-card/);globalThis.__fccTestEnv.FCC_OWNER_EMAIL=before;
});
test('unknown resources return 404 after authorization',async()=>{
 setIdentity('member@example.test');
 for(const index of [2,5]){const route=routes[index][1];const key=index===2?'slug':'asset';assert.equal((await route.GET(new Request('https://club.test/members/missing'),{params:Promise.resolve({[key]:'missing'})})).status,404);}
});
test('reader escapes document and identity HTML and has no export controls',async()=>{
 const {manualPage,libraryPage}=await import('../lib/member-views.ts');
 const malicious={id:'test',title:'<script>alert(1)</script>',description:'<img onerror=bad>',audience:['coach'],label:'Guide',format:'md',blocks:[{kind:'p',text:'<script>private</script>'}]};
 const html=manualPage(malicious,identity('<img src=x onerror=bad>'));
 assert.ok(html.includes('&lt;script&gt;private&lt;/script&gt;'));assert.doesNotMatch(html,/<script>private|<img src=x/);
 const library=libraryPage([malicious],identity('member@example.test'));
 assert.doesNotMatch(library,/download=|window\.print|href="[^\"]*\.(docx|pdf|md)"/);
 assert.match(html,/member-watermark/);assert.match(html,/member-print-notice/);
});
test('legacy download handlers return no document bytes',async()=>{
 const {GET}=await import('../app/library/[...path]/route.ts');const response=GET();assert.equal(response.status,410);assert.match(await response.text(),/disabled/);
});
test('all fifteen library resources have individual protected reading pages',async()=>{
 const manuals=JSON.parse(readFileSync(new URL('../private-source/manuals.json',import.meta.url),'utf8'));
 assert.equal(manuals.length,15);assert.equal(new Set(manuals.map(m=>m.id)).size,15);
 setIdentity('member@example.test');
 for(const manual of manuals){assert.ok(manual.blocks.length>0);assert.equal('href'in manual,false);const response=await routes[2][1].GET(new Request('https://club.test/members/library/'+manual.id),{params:Promise.resolve({slug:manual.id})});assert.equal(response.status,200,manual.id);const html=await response.text();assert.equal((html.match(/class="manual-block /g)||[]).length,manual.blocks.length,manual.id);}
});

test('pilot planning data is embedded only in the authorized page with revised age-specific timing',async()=>{
 setIdentity('member@example.test');
 const response=await routes[3][1].GET(new Request('https://club.test/members/programme'));
 const html=await response.text();assert.doesNotMatch(html,/__PILOT_DATA__|__MEMBER_BANNER__/);
 const payload=html.match(/<script type="application\/json" id="pilot-data">([\s\S]*?)<\/script>/);assert.ok(payload);
 const data=JSON.parse(payload[1]);assert.equal(data.weeks.length,8);
 assert.match(data.plans['winter_6-8'].saturday,/10:00–11:00 a.m./);
 assert.match(data.plans['winter_9-11'].saturday,/11:00 a.m.–noon/);
 assert.match(data.plans['winter_9-11'].copy,/January through March/);
 assert.match(data.plans['spring_9-11'].copy,/not established/);
 assert.doesNotMatch(html,/WⒶNDERERS|Wanderers|US branch/);
});

// Members must render within the private Site preview without allowing arbitrary embeds.
test('protected routes support the Site preview and ChatGPT while excluding other frame parents',async()=>{
 setIdentity('owner@example.test');
 for(const [path,route,params] of routes){
  const response=await route.GET(new Request('https://club.test'+path),{params:Promise.resolve(params)});
  assert.equal(response.status,200,path);
  const policy=response.headers.get('content-security-policy');
  const ancestors=policy.split(';').map(s=>s.trim()).find(s=>s.startsWith('frame-ancestors '));
  assert.deepEqual(ancestors.split(/\s+/).slice(1),["'self'",'https://chatgpt.com'],path);
  assert.equal(response.headers.get('x-frame-options'),null,path);
  assert.match(response.headers.get('cache-control'),/no-store/,path);
 }
});
