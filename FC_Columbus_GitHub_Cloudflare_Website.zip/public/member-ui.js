'use strict';
(() => {
 if(!document.querySelector('[data-member-view]'))return;
 addEventListener('pageshow',event=>{if(event.persisted)location.reload();});
 const notice=()=>{let box=document.querySelector('#member-toast');if(!box){box=document.createElement('div');box.id='member-toast';box.className='member-toast';box.setAttribute('role','status');document.body.append(box);}box.textContent='Member resources are view-only. Printing, saving, copying and sharing are prohibited.';box.classList.add('is-visible');};
 const ownInput=target=>target instanceof Element&&target.closest('input,textarea');
 for(const type of ['copy','cut','dragstart','contextmenu'])document.addEventListener(type,event=>{if(ownInput(event.target))return;event.preventDefault();notice();});
 document.addEventListener('keydown',event=>{if(!(event.ctrlKey||event.metaKey))return;const key=event.key.toLowerCase();if(['p','s'].includes(key)||(['c','x','a'].includes(key)&&!ownInput(event.target))){event.preventDefault();notice();}});
 const libSearch=document.querySelector('#member-library-search'),audience=document.querySelector('#member-library-audience'),sort=document.querySelector('#member-library-sort');
 if(libSearch&&audience){
  const cards=[...document.querySelectorAll('[data-manual-card]')],groups=[...document.querySelectorAll('[data-library-group]')],collections=[...document.querySelectorAll('[data-library-collection]')];let current='all';
  const params=new URLSearchParams(location.search);libSearch.value=params.get('q')||'';
  for(const [control,key] of [[audience,'audience'],[sort,'sort']])if(control&&[...control.options].some(o=>o.value===params.get(key)))control.value=params.get(key);
  if(collections.some(b=>b.dataset.libraryCollection===params.get('collection')))current=params.get('collection');
  const filter=(sync=true)=>{const term=libSearch.value.trim().toLowerCase();let count=0;
   collections.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.libraryCollection===current)));
   for(const card of cards){const shown=card.textContent.toLowerCase().includes(term)&&(audience.value==='all'||card.dataset.audience.split(' ').includes(audience.value))&&(current==='all'||card.dataset.collection===current);card.hidden=!shown;if(shown)count++;}
   for(const group of groups){const items=cards.filter(c=>c.dataset.collection===group.dataset.libraryGroup),visible=items.filter(c=>!c.hidden);group.hidden=visible.length===0;group.querySelector('[data-group-count]').textContent=visible.length+(visible.length===1?' resource':' resources');const sorted=[...items];if(sort?.value==='title')sorted.sort((a,b)=>a.dataset.title.localeCompare(b.dataset.title));else if(sort?.value==='reading')sorted.sort((a,b)=>Number(a.dataset.minutes)-Number(b.dataset.minutes));for(const card of sorted)group.querySelector('.manual-grid').appendChild(card);}
   document.querySelector('#member-library-count').textContent=count+' of '+cards.length+' resources';document.querySelector('#member-library-empty').hidden=count!==0;
   if(sync){const u=new URL(location.href);for(const [key,value]of [['q',libSearch.value.trim()],['audience',audience.value],['collection',current],['sort',sort?.value||'collection']]){if(value&&!(key==='audience'&&value==='all')&&!(key==='collection'&&value==='all')&&!(key==='sort'&&value==='collection'))u.searchParams.set(key,value);else u.searchParams.delete(key);}history.replaceState(null,'',u);}
  };
  libSearch.addEventListener('input',()=>filter());audience.addEventListener('change',()=>filter());sort?.addEventListener('change',()=>filter());collections.forEach(b=>b.addEventListener('click',()=>{current=b.dataset.libraryCollection;filter();}));document.querySelectorAll('[data-library-reset]').forEach(b=>b.addEventListener('click',()=>{libSearch.value='';audience.value='all';if(sort)sort.value='collection';current='all';filter();}));filter(false);
 }
 const search=document.querySelector('#member-reader-search');if(search){const passages=[...document.querySelectorAll('.manual-block')];search.addEventListener('input',()=>{const term=search.value.trim().toLowerCase();let count=0;for(const p of passages){const shown=!term||p.textContent.toLowerCase().includes(term);p.hidden=!shown;if(shown)count++;}document.querySelector('#member-reader-count').textContent=term?count+' matching passages':passages.length+' passages';document.querySelector('#member-reader-empty').hidden=count!==0;});}
})();
