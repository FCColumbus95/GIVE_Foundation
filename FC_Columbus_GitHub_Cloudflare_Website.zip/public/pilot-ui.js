'use strict';
// Shared controls; all program content is supplied by the authorized member page.
(()=>{
 const dataNode=document.querySelector('#pilot-data');if(!dataNode)return;
 let data;try{data=JSON.parse(dataNode.textContent);}catch{return;}
 const q=s=>document.querySelector(s),age=q('#pilot-age'),season=q('#pilot-season'),tabs=[...document.querySelectorAll('[data-pilot-week]')];
 if(!age||!season||!tabs.length||!Array.isArray(data.weeks)||data.weeks.length!==tabs.length)return;
 let current=0;
 function selectWeek(index,sync=true){
  current=Math.max(0,Math.min(data.weeks.length-1,index));const week=data.weeks[current];
  tabs.forEach((b,i)=>{b.setAttribute('aria-selected',String(i===current));b.tabIndex=i===current?0:-1;});
  q('#pilot-week-panel').setAttribute('aria-labelledby','pilot-week-'+(current+1));
  q('[data-pilot-week-label]').textContent='Week '+(current+1)+' · '+week.label;
  q('[data-pilot-week-title]').textContent=week.title;
  q('[data-pilot-week-focus]').textContent=age.value==='6-8'?week.focus6:week.focus9;
  for(const key of ['evidence','family'])q('[data-pilot-week-'+key+']').textContent=week[key];
  q('[data-pilot-prev]').disabled=current===0;q('[data-pilot-next]').disabled=current===data.weeks.length-1;
  q('[data-pilot-count]').textContent=(current+1)+' of '+data.weeks.length+' suggested weeks';
  if(sync){const u=new URL(location.href);u.searchParams.set('pilotAge',age.value);u.searchParams.set('pilotSeason',season.value);u.searchParams.set('pilotWeek',String(current+1));history.replaceState(null,'',u);}
 }
 function update(sync=true){const plan=data.plans[season.value+'_'+age.value];if(!plan)return;for(const key of ['kicker','title','copy','tuesday','thursday','saturday','note','fee'])q('[data-pilot-'+key+']').textContent=plan[key];selectWeek(current,sync);}
 tabs.forEach((b,i)=>{b.addEventListener('click',()=>selectWeek(i));b.addEventListener('keydown',e=>{let next;if(['ArrowRight','ArrowDown'].includes(e.key))next=(i+1)%tabs.length;if(['ArrowLeft','ArrowUp'].includes(e.key))next=(i-1+tabs.length)%tabs.length;if(e.key==='Home')next=0;if(e.key==='End')next=tabs.length-1;if(next!==undefined){e.preventDefault();selectWeek(next);tabs[next].focus();}});});
 q('[data-pilot-prev]').addEventListener('click',()=>selectWeek(current-1));q('[data-pilot-next]').addEventListener('click',()=>selectWeek(current+1));
 age.addEventListener('change',()=>update());season.addEventListener('change',()=>update());
 const params=new URLSearchParams(location.search);for(const [control,key] of [[age,'pilotAge'],[season,'pilotSeason']]){const value=params.get(key);if([...control.options].some(o=>o.value===value))control.value=value;}
 const week=Number(params.get('pilotWeek'));if(Number.isInteger(week)&&week>=1&&week<=data.weeks.length)current=week-1;update(false);
})();
