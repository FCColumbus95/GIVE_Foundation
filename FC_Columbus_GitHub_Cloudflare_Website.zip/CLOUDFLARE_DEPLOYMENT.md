# FC Columbus deployment: GitHub, Cloudflare and DNS

This repository is ready for a private GitHub repository and a Cloudflare Workers deployment. Keep the repository private because the server source contains protected FC Columbus member-library material. The deployed application keeps those routes behind the existing server-side membership checks.

## 1. Create the GitHub repository

1. Create a new **private** repository, for example `fc-columbus-website`.
2. Upload the complete contents of this package. Do not upload the outer ZIP file itself.
3. Make `main` the default branch.

From a local terminal, the equivalent commands are:

```bash
git init
git add .
git commit -m "Launch FC Columbus website"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/fc-columbus-website.git
git push -u origin main
```

## 2. Create Cloudflare credentials

Create a Cloudflare API token with permission to deploy Workers in the account that controls `fccolumbus95.com`. In the GitHub repository, add these Actions secrets:

- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`

The included GitHub Actions workflow installs dependencies, tests the protected member routes, builds the Worker, verifies that protected source did not enter the public client bundle, and deploys on each push to `main`.

## 3. Configure protected membership values

In Cloudflare Workers & Pages, open the deployed Worker, then add these encrypted production secrets:

- `FCC_OWNER_EMAIL` — the approved owner email
- `FCC_MEMBER_EMAILS` — comma-separated approved member emails, including `info@fccolumbus95.com`

Do not commit real addresses or secrets to GitHub. `.env.example` documents the required names only. The members’ centre intentionally fails closed when these values or the signed-in identity are missing.

## 4. Connect the domain

In Cloudflare:

1. Add `fccolumbus95.com` to the correct Cloudflare account if it is not already present.
2. In the deployed Worker, choose **Settings → Domains & Routes → Add → Custom domain**.
3. Add `fccolumbus95.com`.
4. Add `www.fccolumbus95.com` as a second custom domain.
5. Configure a redirect from `www` to the apex domain, or use `www` as the primary and redirect the apex. Use only one canonical address.

When the domain already uses Cloudflare nameservers, Cloudflare creates the required DNS records and TLS certificate. If the registrar still uses other nameservers, replace them with the two nameservers shown in the Cloudflare zone and wait for the zone to become active.

## 5. Verify before announcement

Check the following on desktop and mobile:

- Home-page masthead, rotating club photographs and navigation
- Tryouts and public-program links
- Contact email and social links
- Members link, sign-in rejection for unapproved visitors and access for an approved account
- Members → Library search, filters and reading views
- `https://fccolumbus95.com` and `https://www.fccolumbus95.com`

Do not broaden member access or publish protected curriculum files separately.

