import homepage from '../private-source/home.html?raw';
import {applySocialMarkup} from '../lib/social-links';
export default function Home(){return <div dangerouslySetInnerHTML={{__html:applySocialMarkup(homepage)}}/>;}
