'use client';
import {useEffect} from 'react';
export default function ClubInteractions(){
 useEffect(()=>{
  // Wire imperative enhancements after React finishes hydrating the page.
  if(document.querySelector('script[data-fcc-interactions]'))return;
  const script=document.createElement('script');script.src='/club.js';script.dataset.fccInteractions='true';document.body.appendChild(script);
 },[]);
 return null;
}
