'use client';
import {useEffect,useRef,useState} from 'react';

const photos=[
 {src:'/assets/team-present.jpg',alt:'FC Columbus youth team in red and yellow kits with their coach and tournament medals',label:'The present · FC Columbus',caption:'Our community. Our next chapter.'},
 {src:'/assets/santos-team-trophies.jpg',alt:'A past Santos FC girls team together on the field holding trophies',label:'Our roots · Santos FC',caption:'A history built together.'},
 {src:'/assets/santos-team-portrait.jpg',alt:'A past Santos FC boys team and coach together with trophies',label:'Our roots · Santos FC',caption:'The joy of the game lives on.'}
];

export default function HomeSlideshow(){
 const [current,setCurrent]=useState(0),[playing,setPlaying]=useState(false),[hovered,setHovered]=useState(false),[visible,setVisible]=useState(true),[inView,setInView]=useState(true);
 const playbackIntent=useRef<boolean|null>(null);
 const root=useRef<HTMLElement>(null),touch=useRef<{x:number;y:number}|null>(null);
 useEffect(()=>{
  const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
  setPlaying(!preference.matches);
  const motion=()=>{if(preference.matches)setPlaying(false);};
  const visibility=()=>setVisible(!document.hidden);visibility();
  preference.addEventListener('change',motion);document.addEventListener('visibilitychange',visibility);
  const observer=new IntersectionObserver(entries=>setInView(entries[0]?.isIntersecting??false),{threshold:.2});
  if(root.current)observer.observe(root.current);
  return()=>{preference.removeEventListener('change',motion);document.removeEventListener('visibilitychange',visibility);observer.disconnect();};
 },[]);
 useEffect(()=>{
  if(!playing||hovered||!visible||!inView)return;
  const timer=window.setInterval(()=>setCurrent(index=>(index+1)%photos.length),6000);
  return()=>window.clearInterval(timer);
 },[playing,hovered,visible,inView]);
 function select(index:number){setCurrent((index+photos.length)%photos.length);setPlaying(false);}
 const photo=photos[current];
 return <figure ref={root} className="hero-visual hero-slideshow" role="region" aria-roledescription="carousel" aria-label="FC Columbus through the years" onMouseEnter={()=>setHovered(true)} onMouseLeave={()=>setHovered(false)} onFocusCapture={event=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null))setPlaying(false);}} onTouchStart={event=>{const point=event.touches[0];touch.current={x:point.clientX,y:point.clientY};}} onTouchEnd={event=>{const start=touch.current;touch.current=null;if(!start)return;const end=event.changedTouches[0],x=end.clientX-start.x,y=end.clientY-start.y;if(Math.abs(x)>45&&Math.abs(x)>Math.abs(y))select(current+(x<0?1:-1));}}>
  <div className="photo-frame"><div className="hero-slides">{photos.map((item,index)=><div key={item.src} className={'hero-slide'+(current===index?' is-active':'')} role="group" aria-roledescription="slide" aria-label={`${index+1} of ${photos.length}`} aria-hidden={current!==index}><img src={item.src} alt={item.alt} width={index===0?1170:index===1?900:325} height={index===0?707:index===1?563:325} fetchPriority={index===0?'high':'auto'} draggable={false}/></div>)}</div></div>
  <figcaption className="slideshow-footer"><div className="slideshow-caption"><span>{photo.label}</span><b>{photo.caption}</b></div><div className="slideshow-controls"><button type="button" className="slide-arrow" aria-label="Previous photo" onClick={()=>select(current-1)}>←</button><div className="slide-dots" role="group" aria-label="Choose a photo">{photos.map((item,index)=><button type="button" key={item.src} className="slide-dot" aria-label={`Show photo ${index+1}: ${item.label}`} aria-pressed={current===index} onClick={()=>select(index)}><span/></button>)}</div><button type="button" className="slide-arrow" aria-label="Next photo" onClick={()=>select(current+1)}>→</button><button type="button" className="slide-playback" aria-label={playing?'Pause photo slideshow':'Play photo slideshow'} onPointerDown={()=>{playbackIntent.current=!playing;}} onClick={event=>{setPlaying(event.detail>0?(playbackIntent.current??!playing):!playing);playbackIntent.current=null;}}><span aria-hidden="true">{playing?'Ⅱ':'▶'}</span>{playing?'Pause':'Play'}</button><span className="slide-count" aria-hidden="true">{String(current+1).padStart(2,'0')} / 03</span></div></figcaption>
  <p className="slideshow-status" role="status" aria-live={playing?'off':'polite'} aria-atomic="true">Photo {current+1} of {photos.length}. {photo.label}. {photo.caption}</p>
 </figure>;
}
