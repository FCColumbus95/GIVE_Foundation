export {downloadDenied as GET} from '../../lib/download-denied';
