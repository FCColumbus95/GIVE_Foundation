export const dynamic = 'force-dynamic';
import manuals from '../../private-source/manuals.json';
import {memberAccess,protectedResponse} from '../../lib/member-access';
import {gatePage,memberHomePage,type Manual} from '../../lib/member-views';
export async function GET(){const access=await memberAccess();if(!access.allowed||!access.user)return protectedResponse(gatePage(access.role,'/members'),access.role==='anonymous'?401:access.role==='unconfigured'?503:403);return protectedResponse(memberHomePage(manuals as Manual[],access.user));}
