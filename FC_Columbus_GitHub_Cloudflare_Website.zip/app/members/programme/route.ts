import {socialLinksMarkup} from '../../../lib/social-links';
export const dynamic = 'force-dynamic';
import programme from '../../../private-source/programme.html?raw';
import pilotData from '../../../private-source/pilot-data.json';
import {memberAccess,protectedResponse} from '../../../lib/member-access';
import {gatePage,memberBanner} from '../../../lib/member-views';
export async function GET(){const access=await memberAccess();if(!access.allowed||!access.user)return protectedResponse(gatePage(access.role,'/members/programme'),access.role==='anonymous'?401:access.role==='unconfigured'?503:403);return protectedResponse(programme.replace('__SOCIAL_MEMBER__',socialLinksMarkup('member')).replace('__MEMBER_BANNER__',memberBanner(access.user)).replace('__PILOT_DATA__',JSON.stringify(pilotData).replaceAll('<','\\u003c')));}
