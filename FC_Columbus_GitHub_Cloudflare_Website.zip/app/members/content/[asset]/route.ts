export const dynamic='force-dynamic';
import programmeScript from '../../../../private-source/programme.js?raw';
import campus from '../../../../private-source/campus.json';
import indoor from '../../../../private-source/indoor.json';
import twin from '../../../../private-source/twin-halls.json';
import {memberAccess,protectedResponse} from '../../../../lib/member-access';
export async function GET(_request:Request,context:{params:Promise<{asset:string}>}){const access=await memberAccess();if(!access.allowed)return protectedResponse('Approved membership is required.',access.role==='anonymous'?401:403,'text/plain; charset=utf-8');const{asset}=await context.params;if(asset==='programme.js')return protectedResponse(programmeScript,200,'text/javascript; charset=utf-8');if(asset==='campus.png'||asset==='indoor.png'||asset==='twin-halls.webp'){const image=asset==='campus.png'?campus:asset==='indoor.png'?indoor:twin;const data=Uint8Array.from(atob(image.base64),c=>c.charCodeAt(0));return protectedResponse(data,200,asset==='twin-halls.webp'?'image/webp':'image/png');}return protectedResponse('Resource not found.',404,'text/plain; charset=utf-8');}
