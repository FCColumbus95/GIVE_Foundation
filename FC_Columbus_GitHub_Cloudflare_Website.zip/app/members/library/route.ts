export const dynamic='force-dynamic';
import resources from '../../../private-source/manuals.json';
import {memberAccess,protectedResponse} from '../../../lib/member-access';
import {gatePage,libraryPage,type Manual} from '../../../lib/member-views';
export async function GET(){const access=await memberAccess();if(!access.allowed||!access.user)return protectedResponse(gatePage(access.role,'/members/library'),access.role==='anonymous'?401:access.role==='unconfigured'?503:403);return protectedResponse(libraryPage(resources as Manual[],access.user));}
