export const dynamic = 'force-dynamic';
import manuals from '../../../../private-source/manuals.json';
import {memberAccess,protectedResponse} from '../../../../lib/member-access';
import {gatePage,manualPage,type Manual} from '../../../../lib/member-views';
export async function GET(_request:Request,context:{params:Promise<{slug:string}>}){const {slug}=await context.params;const access=await memberAccess();if(!access.allowed||!access.user)return protectedResponse(gatePage(access.role,'/members/library/'+encodeURIComponent(slug)),access.role==='anonymous'?401:access.role==='unconfigured'?503:403);const manual=(manuals as Manual[]).find(m=>m.id===slug);if(!manual)return protectedResponse('Member resource not found.',404,'text/plain; charset=utf-8');return protectedResponse(manualPage(manual,access.user));}
