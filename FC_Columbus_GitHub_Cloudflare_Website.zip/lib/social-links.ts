// Club-owned handles documented by the existing club site and NPSL club announcement.
// Keep unconfirmed platforms out of navigation until the owner supplies their exact URLs.
export const SOCIAL_PROFILES=[
 {id:'instagram',name:'Instagram',handle:'@fccolumbus95',url:'https://www.instagram.com/fccolumbus95/',description:'Club photos and moments.',source:'https://www.fccolumbus95.com/'},
 {id:'facebook',name:'Facebook',handle:'@fccolumbus95',url:'https://www.facebook.com/fccolumbus95/',description:'Club news and community.',source:'https://www.npsl.com/4399/'},
 {id:'x',name:'X / Twitter',handle:'@FCColumbus95',url:'https://x.com/FCColumbus95',description:'Updates and conversation.',source:'https://www.npsl.com/4399/'}
] as const;
export const CLUB_LINK_HUB='https://lnk.bio/fccolumbus95';
const icons:Record<string,string>={
 instagram:'<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor"/>',
 facebook:'<path fill="currentColor" d="M14 8.5V6.7c0-.8.5-1.1 1.1-1.1H18V2h-3.2C11.3 2 10 4.2 10 6.6v1.9H7v3.8h3V22h4v-9.7h3l.6-3.8H14z"/>',
 x:'<path fill="currentColor" d="M18.9 2H22l-6.8 7.8L23.2 22h-6.7l-5.3-7-6.1 7H2l7.3-8.4L1 2h6.9l4.8 6.4L18.9 2ZM17.8 20h1.9L6.7 4H4.7L17.8 20Z"/>'
};
const icon=(id:string)=>`<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">${icons[id]}</svg>`;
export function socialLinksMarkup(location:string){return `<nav class="club-social-links club-social-${location}" aria-label="FC Columbus social media">${SOCIAL_PROFILES.map(p=>`<a href="${p.url}" target="_blank" rel="noopener noreferrer" aria-label="FC Columbus on ${p.name} (opens in a new tab)" title="${p.name}">${icon(p.id)}<span>${p.name}</span></a>`).join('')}</nav>`;}
export function socialSectionMarkup(){return `<section id="social" class="section club-social-section"><div class="wrap"><div class="section-heading"><div><p class="eyebrow red">FOLLOW THE CLUB</p><h2>ONE CLUB.<br>MORE CONNECTIONS.</h2></div><p class="section-intro">Stay connected with the FC Columbus community, on and off the field.</p></div><div class="club-social-cards">${SOCIAL_PROFILES.map(p=>`<a class="club-social-card" href="${p.url}" target="_blank" rel="noopener noreferrer" aria-label="Follow FC Columbus on ${p.name} (opens in a new tab)"><span class="social-card-icon">${icon(p.id)}</span><span class="social-card-name">${p.name}</span><span class="social-card-handle">${p.handle}</span><p>${p.description}</p><span class="social-card-follow">Follow FC Columbus <span aria-hidden="true">↗</span></span></a>`).join('')}</div><a class="text-link social-hub-link" href="${CLUB_LINK_HUB}" target="_blank" rel="noopener noreferrer">Explore the club’s link hub <span aria-hidden="true">↗</span></a></div></section>`;}
export function applySocialMarkup(homepage:string){return homepage.replaceAll('__SOCIAL_TOPBAR__',socialLinksMarkup('topbar')).replaceAll('__SOCIAL_INLINE__',socialLinksMarkup('inline')).replaceAll('__SOCIAL_CONTACT__',socialLinksMarkup('contact')).replaceAll('__SOCIAL_FOOTER__',socialLinksMarkup('footer')).replaceAll('__SOCIAL_SECTION__',socialSectionMarkup());}
