export const COLLECTIONS=[
 {id:'curriculum',title:'Curriculum & Manuals',description:'Structured learning, coaching practice, technique and player development.',number:'01'},
 {id:'handbooks',title:'Handbooks',description:'Club culture, leadership, responsibilities and institutional guidance.',number:'02'},
 {id:'guides',title:'Club Guides',description:'Club identity, family information and Hilliard pilot planning.',number:'03'},
 {id:'articles',title:'Articles & Reading Notes',description:'Focused readings and clearly attributed excerpts from club resources.',number:'04'}
] as const;
export function readingMinutes(resource:{blocks:{text:string}[]}){return Math.max(1,Math.ceil(resource.blocks.reduce((n,b)=>n+b.text.trim().split(/\s+/).length,0)/220));}
