import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../app/chatgpt-auth';
import {memberRole,isMember,PRIVATE_HEADERS} from './member-policy';
export async function memberAccess(){
  const user=await getChatGPTUser();
  const runtime=env as unknown as Record<string,string|undefined>;
  const role=memberRole(user,{ownerEmail:runtime.FCC_OWNER_EMAIL??'',memberEmails:runtime.FCC_MEMBER_EMAILS??''});
  return {user,role,allowed:isMember(role)};
}
export function protectedResponse(body:BodyInit|null,status=200,type='text/html; charset=utf-8'){
  return new Response(body,{status,headers:{...PRIVATE_HEADERS,'Content-Type':type}});
}
