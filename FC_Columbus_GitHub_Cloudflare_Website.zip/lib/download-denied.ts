import {PRIVATE_HEADERS} from './member-policy';
export function downloadDenied(){return new Response('Document downloads and legacy file links are disabled. Approved members must use the view-only library.',{status:410,headers:{...PRIVATE_HEADERS,'Content-Type':'text/plain; charset=utf-8'}});}
