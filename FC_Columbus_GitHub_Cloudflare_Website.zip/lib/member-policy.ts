export type Identity = { userId:string; email:string; displayName:string };
export type MemberConfig = { ownerEmail:string; memberEmails:string };
export type MemberRole = 'owner' | 'member' | 'anonymous' | 'pending' | 'unconfigured';
export function memberRole(user:Identity|null, config:MemberConfig):MemberRole {
  if(!user?.userId?.trim() || !user.email?.trim()) return 'anonymous';
  const email=user.email.trim().toLowerCase();
  const owner=config.ownerEmail.trim().toLowerCase();
  if(!owner) return 'unconfigured';
  if(email===owner) return 'owner';
  const approved=new Set(config.memberEmails.split(/[\n,;]/).map(e=>e.trim().toLowerCase()).filter(Boolean));
  return approved.has(email) ? 'member' : 'pending';
}
export function isMember(role:MemberRole):boolean { return role==='owner'||role==='member'; }
export const PRIVATE_HEADERS:Record<string,string> = {
  'Cache-Control':'private, no-store, max-age=0, must-revalidate',
  'CDN-Cache-Control':'no-store',
  'Cloudflare-CDN-Cache-Control':'no-store',
  'Pragma':'no-cache','Expires':'0',
  'X-Robots-Tag':'noindex, nofollow, noarchive, nosnippet',
  'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
  'Content-Security-Policy':"frame-ancestors 'self' https://chatgpt.com; object-src 'none'; base-uri 'self'; form-action 'self'",
  'Permissions-Policy':'display-capture=()'
};
